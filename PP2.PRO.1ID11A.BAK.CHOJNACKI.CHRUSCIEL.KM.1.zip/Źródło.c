#define _CRT_SECURE_NO_WARNINGS           //Potrzebne żeby nie było błędów podczas kompilacji kodu w visual studio 2022
#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include <allegro5\allegro5.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>

#define MAKSYMALNA_DLUGOSC 256
#define ILOSC_PYTAN 12
#define MAKSYMALNA_ILOSC_PYTAN 100

#define MAKS_NAZWA 50
#define MAKS_RANGA 20
#define MAKS_PROFILE 3


//////////////////////////////////////////////////////////////////////////////////////// Struktura przechowująca pytanie i jego odpowiedzi
typedef struct Pytanie {
    char tresc[MAKSYMALNA_DLUGOSC];
    char odpowiedzi[4][MAKSYMALNA_DLUGOSC];
    char poprawna_odpowiedz;
    struct Pytanie* nastepne;
} Pytanie;

///////////////////////////////////////////////////////////////////////////////////////  Struktura dla gracza
typedef struct {
    char nazwa_gracza[MAKS_NAZWA];
    int xp;
    char ranga[MAKS_RANGA];
} ProfilGracz;

typedef struct { // KCH: Potrzebne do przycisków
    float x, y, width, height;
    const char* akcja;
} Przycisk;

typedef enum {
    STAN_MENU,
    STAN_INSTRUKCJA,
    STAN_PROFIL,
    STAN_POZIOM,
    STAN_GRY,
    STAN_KONIEC_GRY
} StanGry;

typedef struct {
    Pytanie* aktualne_pytanie;
    Pytanie* lista_pytan;
    int numer_pytania;
    int licznik_poprawnych;
    int kolo50_uzyte;
    int telefon_uzyty;
    int* ukryte_odpowiedzi;
    ProfilGracz* profil;
    int ileLatwych;
    int ileSrednich;
    int ileTrudnych;
} StanGryDane;

ProfilGracz* aktywny_profil = NULL;
int aktywny_profil_index = -1;
ALLEGRO_BITMAP* poziom_bitmap = NULL;
StanGry stan = STAN_MENU;
char wpisywany_tekst[MAKS_NAZWA] = "";
bool wprowadzanie_nazwy = false;
StanGryDane stan_gry;
ALLEGRO_BITMAP* tlo_gry = NULL;
ALLEGRO_FONT* czcionka_duza = NULL;
ALLEGRO_FONT* czcionka_mala = NULL;

Przycisk przyciski_gry[] = {
    {50, 250, 280, 60, "ODP_A"},
    {460, 250, 280, 60, "ODP_B"},
    {50, 340, 280, 60, "ODP_C"},
    {460, 340, 280, 60, "ODP_D"},
    {50, 450, 280, 60, "TELEFON"},
    {460, 450, 280, 60, "POL_NA_POL"}
};
const int liczba_przyciskow_gry = sizeof(przyciski_gry) / sizeof(Przycisk);

/////////////////////////////////////////////////////////////////////////////////////// Tworzy nowy węzeł pytania i kopiuje do niego dane
Pytanie* stworzWezel(char* tresc, char odpowiedzi[][MAKSYMALNA_DLUGOSC], char poprawna_odpowiedz)
{
    Pytanie* nowyWezel = (Pytanie*)malloc(sizeof(Pytanie));
    if (!nowyWezel) {
        printf("Błąd alokacji pamięci!\n");
        exit(1);
    }
    strcpy(nowyWezel->tresc, tresc);
    for (int i = 0; i < 4; i++) {
        strcpy(nowyWezel->odpowiedzi[i], odpowiedzi[i]);
    }
    nowyWezel->poprawna_odpowiedz = poprawna_odpowiedz;
    nowyWezel->nastepne = NULL;
    return nowyWezel;
}

/////////////////////////////////////////////////////////////////////////////////////// Dodaje pytanie do listy cyklicznej
void dodajDoListy(Pytanie** glowa, Pytanie* nowyWezel)
{
    if (!*glowa) {
        *glowa = nowyWezel;
        nowyWezel->nastepne = *glowa;
    }
    else {
        Pytanie* temp = *glowa;
        while (temp->nastepne != *glowa) {
            temp = temp->nastepne;
        }
        temp->nastepne = nowyWezel;
        nowyWezel->nastepne = *glowa;
    }
    // 
    printf("Dodano pytanie: %s\n", nowyWezel->tresc); // Debugowanie
    // 
}

////////////////////////////////////////////////////////////////////////////////////// Funkcje zwiazane z graczem
void zapis_gracz(ProfilGracz profile[], int liczba_profili) {
    FILE* zapis = fopen("profile.txt", "w");
    if (zapis == NULL) {
        printf("Nie można otworzyć pliku do zapisu!\n");
        return;
    }
    fwrite(profile, sizeof(ProfilGracz), liczba_profili, zapis);
    fclose(zapis);
}

void wczytaj_profile(ProfilGracz profile[], int* liczba_profili) {
    FILE* plik = fopen("profile.txt", "r");
    if (plik == NULL) {
        *liczba_profili = 0;
        return;
    }
    *liczba_profili = fread(profile, sizeof(ProfilGracz), MAKS_PROFILE, plik);
    fclose(plik);
}

void pokaz_profile(ProfilGracz profile[], int liczba_profili) {
    printf("\nDostępne profile:\n");
    for (int i = 0; i < MAKS_PROFILE; i++) {
        if (i < liczba_profili && profile[i].nazwa_gracza[0] != '\0') {
            printf("%d. %s (XP: %d, Ranga: %s)\n", i + 1, profile[i].nazwa_gracza, profile[i].xp, profile[i].ranga);
        }
        else {
            printf("%d. [Pusty slot]\n", i + 1);
        }
    }
}

int wybierz_lub_utworz_profil(ProfilGracz profile[], int* liczba_profili) {
    int wybor;

    while (1) {
        pokaz_profile(profile, *liczba_profili);
        printf("\nOpcje:\n");
        printf("1-3: Wybierz profil\n");
        printf("4: Utwórz nowy profil\n");
        printf("5: Usuń profil\n");
        printf("0: Powrót\n");
        printf("Twój wybór: ");
        scanf("%d", &wybor);

        if (wybor >= 1 && wybor <= 3) {
            int index = wybor - 1;
            if (index < *liczba_profili && profile[index].nazwa_gracza[0] != '\0') {
                return index;  // Zwracamy wybrany slot
            }
            else {
                system("cls");
                printf("Ten slot jest pusty.\n");
            }
        }
        else if (wybor == 4) {
            if (*liczba_profili >= MAKS_PROFILE) {
                printf("Osiągnięto maksymalną liczbę profili.\n");
                continue;
            }

            for (int i = 0; i < MAKS_PROFILE; i++) {
                if (i >= *liczba_profili || profile[i].nazwa_gracza[0] == '\0') {
                    printf("Podaj nazwę gracza: ");
                    scanf("%s", profile[i].nazwa_gracza);
                    profile[i].xp = 0;
                    strcpy(profile[i].ranga, "Technik Informatyk");
                    if (i >= *liczba_profili) (*liczba_profili)++;
                    zapis_gracz(profile, *liczba_profili);
                    system("cls");
                    printf("Utworzono profil: %s\n", profile[i].nazwa_gracza);
                    return i;
                }
            }

        }
        else if (wybor == 5) {
            printf("Podaj numer profilu do usunięcia (1-3): ");
            int do_usuniecia;
            scanf("%d", &do_usuniecia);
            int idx = do_usuniecia - 1;
            if (idx >= 0 && idx < *liczba_profili && profile[idx].nazwa_gracza[0] != '\0') {
                profile[idx].nazwa_gracza[0] = '\0';  // oznacz jako pusty
                profile[idx].xp = 0;
                strcpy(profile[idx].ranga, "");
                // przesuwamy profile w górę jeśli trzeba
                for (int i = idx; i < *liczba_profili - 1; i++) {
                    profile[i] = profile[i + 1];
                }
                (*liczba_profili)--;
                zapis_gracz(profile, *liczba_profili);
                system("cls");
                printf("Profil usunięty.\n");
            }
            else {
                printf("Nieprawidłowy numer profilu.\n");
            }

        }
        else if (wybor == 0) {
            return -1; // powrót
        }
        else {
            printf("Nieprawidłowy wybór.\n");
        }
    }
}



////////////////////////////////////////////////////////////////////////////////////// Aktualizuje ilość XP 
int aktualizujXP(ProfilGracz* profil, int licznikLatwe, int licznikSrednie, int licznikTrudne)
{
    int xp = (licznikLatwe * 10) + (licznikSrednie * 50) + (licznikTrudne * 100);
    profil->xp += xp;
    return xp;
}

////////////////////////////////////////////////////////////////////////////////////// Aktualizuje range użytkownika
void aktualizujRange(ProfilGracz* profil)
{
    if (profil->xp >= 1000)
    {
        strcpy(profil->ranga, "Inżynier");
    }
    else if (profil->xp >= 10000)
    {
        strcpy(profil->ranga, "Magister");
    }
    else if (profil->xp >= 100000)
    {
        strcpy(profil->ranga, "Profesor");
    }
    else
    {
        strcpy(profil->ranga, "Technik Informatyk");
    }
}

////////////////////////////////////////////////////////////////////////////////////// Zapisuje aktualny progres gracza
void progres(ProfilGracz* profil, int licznikLatwe, int licznikSrednie, int licznikTrudne, int liczba_profili)
{
    aktualizujXP(profil, licznikLatwe, licznikSrednie, licznikTrudne);
    aktualizujRange(profil);
    zapis_gracz(&profil[0], liczba_profili);

    printf("Aktualny XP: %d! Aktualna ranga: %s!", profil->xp, profil->ranga);
}
////////////////////////////////////////////////////////////////////////////////////// Wczytuje pytania z pliku do tablicy
int wczytajWszystkiePytania(const char* nazwaPliku, Pytanie* pytania[], int* ilosc_pytan)
{
    FILE* plik = fopen(nazwaPliku, "r");
    if (!plik) {
        printf("Nie można otworzyć pliku %s!\n", nazwaPliku);
        exit(1);
    }

    char tresc[MAKSYMALNA_DLUGOSC];
    char odpowiedzi[4][MAKSYMALNA_DLUGOSC];
    char poprawna;
    *ilosc_pytan = 0;

    while (*ilosc_pytan < MAKSYMALNA_ILOSC_PYTAN && fscanf(plik, " %[^\n] %[^\n] %[^\n] %[^\n] %[^\n] %c", tresc, odpowiedzi[0], odpowiedzi[1], odpowiedzi[2], odpowiedzi[3], &poprawna) == 6)
    {
        pytania[*ilosc_pytan] = stworzWezel(tresc, odpowiedzi, poprawna);
        (*ilosc_pytan)++;
    }

    fclose(plik);
    return *ilosc_pytan;
}

///////////////////////////////////////////////////////////////////////// Wybiera losowe pytania z poziomów trudności i tworzy listę cykliczną
void wybierzLosowePytaniaZPoziomow(Pytanie* pytaniaLatwe[], int iloscLatwe, Pytanie* pytaniaSrednie[], int iloscSrednie, Pytanie* pytaniaTrudne[], int iloscTrudne, int iloscDoWylosowaniaLatwe, int iloscDoWylosowaniaSrednie, int iloscDoWylosowaniaTrudne, Pytanie** glowa)
{
    int indeksy[MAKSYMALNA_ILOSC_PYTAN];

    //Algorytm Knuth shuffle
    // Losuj łatwe pytania
    if (iloscDoWylosowaniaLatwe > iloscLatwe) iloscDoWylosowaniaLatwe = iloscLatwe;
    for (int i = 0; i < iloscLatwe; i++) indeksy[i] = i;
    for (int i = iloscLatwe - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = indeksy[i];
        indeksy[i] = indeksy[j];
        indeksy[j] = temp;
    }
    for (int i = 0; i < iloscDoWylosowaniaLatwe; i++) {
        dodajDoListy(glowa, pytaniaLatwe[indeksy[i]]);
    }

    // Losuj średnie pytania
    if (iloscDoWylosowaniaSrednie > iloscSrednie) iloscDoWylosowaniaSrednie = iloscSrednie;
    for (int i = 0; i < iloscSrednie; i++) indeksy[i] = i;
    for (int i = iloscSrednie - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = indeksy[i];
        indeksy[i] = indeksy[j];
        indeksy[j] = temp;
    }
    for (int i = 0; i < iloscDoWylosowaniaSrednie; i++) {
        dodajDoListy(glowa, pytaniaSrednie[indeksy[i]]);
    }

    // Losuj trudne pytania
    if (iloscDoWylosowaniaTrudne > iloscTrudne) iloscDoWylosowaniaTrudne = iloscTrudne;
    for (int i = 0; i < iloscTrudne; i++) indeksy[i] = i;
    for (int i = iloscTrudne - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = indeksy[i];
        indeksy[i] = indeksy[j];
        indeksy[j] = temp;
    }
    for (int i = 0; i < iloscDoWylosowaniaTrudne; i++) {
        dodajDoListy(glowa, pytaniaTrudne[indeksy[i]]);
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////    Kolo 50/50
void Kolo50(Pytanie* pytanie, int doUkrycia[4])
{
    int licznik = 0;
    while (licznik < 2)
    {
        int i = rand() % 4;
        char litera = 'A' + i;
        if (litera != pytanie->poprawna_odpowiedz && doUkrycia[i] == 0)  // Sprawdza czy pytanie (literka) nie jest poprawna odpowiedzia i czy nie zostalo ukryte juz
        {
            doUkrycia[i] = 1;
            licznik++;
        }
    }
}

//////////////////////////////////////////////////////////////////        Kolo ratunkowe TelefonDoPrzyjaciela
void TelefonDoPrzyjaciela(Pytanie* pytanie, int doUkrycia[4])
{
    char tresc[4][255];
    FILE* plik = fopen("Telefon.txt", "r");
    srand(time(NULL));
    int m = rand() % 4; //ilosc tekstow w pliku  = zmienic    w tresc[]  w m=rand    i while(g<
    int g = 0;

    srand(time(NULL));
    int GAMBLING = rand() % 5;

    if (GAMBLING != 1) {
        while (g < 4 && fgets(tresc[g], 255, plik) != NULL)
        {
            size_t len = strlen(tresc[g]);
            if (len > 0 && tresc[g][len - 1] == '\n') {
                tresc[g][len - 1] = '\0';
            }
            g++;
        }

        fclose(plik);

        int indexPoprawnej = pytanie->poprawna_odpowiedz - 'A';

        printf("%s %s\n", tresc[m], pytanie->odpowiedzi[indexPoprawnej]);
    }
    else
    {
        printf("Przykro mi to mówić ale pierwszy raz o takim czyms słysze\n");
    }
}

/////////////////////////////////////////////////////////////////////////// Zadaje pytania graczowi, pobiera jego odpowiedzi i sprawdza poprawność
void zadajPytania(Pytanie* glowa, ProfilGracz* aktywny, int liczba_profilow, int ileLatwych, int ileSrednich, int ileTrudnych)
{
    Pytanie* biezace = glowa;

    int kolo50Uzyte = 0;
    int telefonUzyty = 0;
    int koloUzyte = 0;
    const int maksKolo = 3;
    int licznikpoprawnych = 0;
    int correct_easy = 0, correct_medium = 0, correct_hard = 0;
    int ukryteOdpowiedzi[4] = { 0 }; // 0 = widoczna, 1 = ukryta


    for (int i = 0; i < ILOSC_PYTAN; i++) {
        int koloUzyteDlaPytania = 0;
        // Zresetuj ukryte odpowiedzi przy nowym pytaniu
        for (int j = 0; j < 4; j++) {
            ukryteOdpowiedzi[j] = 0;
        }

        while (1) {
            printf("\nPytanie %d:\n%s\n", i + 1, biezace->tresc);

            for (int j = 0; j < 4; j++) {
                if (!ukryteOdpowiedzi[j]) {
                    printf("%c) %s\n", 'A' + j, biezace->odpowiedzi[j]);
                }
            }

            if (koloUzyte < maksKolo) {
                printf("\nWpisz 'K' aby użyć koła ratunkowego 50/50\n");
                printf("Wpisz 'T' aby użyć koła ratunkowego Telefon do Przyjaciela\n");
                printf("Pozostalo: %d koła ratunkowe\n\n", maksKolo - koloUzyte);
            }

            char odpowiedz;
            printf("Twoja odpowiedź: ");
            scanf(" %c", &odpowiedz);
            odpowiedz = toupper(odpowiedz);

            if (odpowiedz == 'K') { // 50/50
                if (koloUzyteDlaPytania) {
                    system("cls");
                    printf("Dla tego pytania użyto już koła ratunkowego.\n");
                }
                else if (koloUzyte < maksKolo && !kolo50Uzyte) {
                    system("cls");
                    Kolo50(biezace, ukryteOdpowiedzi);
                    koloUzyte++;
                    kolo50Uzyte = 1;
                    koloUzyteDlaPytania = 1;
                    printf("Użyto koła ratunkowego 50/50!\n");
                }
                else if (kolo50Uzyte) {
                    system("cls");
                    printf("Koło 50/50 zostało już użyte.\n");
                }
                else {
                    system("cls");
                    printf("Wykorzystano już wszystkie dostępne koła ratunkowe.\n");
                }
                continue;
            }

            // Telefon do przyjaciela
            if (odpowiedz == 'T') {
                if (koloUzyteDlaPytania) {
                    system("cls");
                    printf("Dla tego pytania użyto już koła ratunkowego.\n");
                }
                else if (koloUzyte < maksKolo && !telefonUzyty) {
                    system("cls");
                    koloUzyte++;
                    telefonUzyty = 1;
                    koloUzyteDlaPytania = 1;
                    printf("Użyto koła ratunkowego Telefon do Przyjaciela!\n\n");
                    TelefonDoPrzyjaciela(biezace, ukryteOdpowiedzi);
                }
                else if (telefonUzyty) {
                    system("cls");
                    printf("Telefon do przyjaciela został już użyty.\n");
                }
                else {
                    system("cls");
                    printf("Wykorzystano już wszystkie dostępne koła ratunkowe.\n");
                }
                continue;
            }

            // Sprawdzenie odpowiedzi
            if (odpowiedz >= 'A' && odpowiedz <= 'D') {
                if (odpowiedz == biezace->poprawna_odpowiedz) {
                    system("cls");
                    printf("Poprawna odpowiedź!\n");
                    licznikpoprawnych++;

                    if (i < ileLatwych) correct_easy++;
                    else if (i < ileLatwych + ileSrednich) correct_medium++;
                    else correct_hard++;
                    break;
                }
                else {
                    system("cls");
                    printf("Bledna odpowiedz! Poprawna to: %c\n", biezace->poprawna_odpowiedz);
                    printf("\nGra zakonczona. Wracasz do menu glownego.\n");
                    printf("\nUdalo Ci sie odpowiedziec na %d pytan poprawnie. BRAWOOO.\n", licznikpoprawnych);   //tymczasowe
                    Sleep(3000);
                    progres(aktywny, correct_easy, correct_medium, correct_hard, liczba_profilow);
                    return;
                }
                break;
            }
            else {
                system("cls");
                printf("Nieprawidłowa odpowiedź. Wprowadź A, B, C, D, K lub T.\n");
            }
        }

        // Następne pytanie
        biezace = biezace->nastepne;
        kolo50Uzyte = 0;
        telefonUzyty = 0;
    }
    system("cls");
    printf("Gratulacje! Odpowiedziałeś poprawnie na wszystkie %d pytań!\n", ILOSC_PYTAN);
    Sleep(2000);
    progres(aktywny, correct_easy, correct_medium, correct_hard, liczba_profilow);
}

/////////////////////////////////////////////////////////////////////////////////////// Funkcja dla menu
void menu() {
    printf("=====================================\n");
    printf("       WITAJ W CI CO WIEDZO\n");
    printf("=====================================\n");
    printf("1. Rozpocznij grę\n");
    printf("2. Instrukcja\n");
    printf("3. Wyjście\n");
    printf("Wybierz opcję: ");
}

void rysuj_poziomy() {
    al_clear_to_color(al_map_rgb(0, 0, 0));
    if (poziom_bitmap) {
        al_draw_bitmap(poziom_bitmap, 0, 0, 0);
    }

    ALLEGRO_FONT* font = al_load_ttf_font("tahoma.ttf", 24, 0);
    if (aktywny_profil) {
        al_draw_textf(font, al_map_rgb(255, 255, 255), 20, 20, 0,
            "Witaj, %s (XP: %d, Ranga: %s)",
            aktywny_profil->nazwa_gracza,
            aktywny_profil->xp,
            aktywny_profil->ranga);
    }
    al_destroy_font(font);
}

void draw_wrapped_text(ALLEGRO_FONT* font, ALLEGRO_COLOR color,
    float x, float y, float max_w, float line_height,
    const char* text)
{
    char buf[1024];
    strncpy(buf, text, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = 0;

    float cur_x = x;
    float cur_y = y;
    char* word = strtok(buf, " ");
    while (word) {
        int w = al_get_text_width(font, word);
        // sprawdzamy, czy słowo się zmieści w aktualnym wierszu
        if (cur_x + w > x + max_w) {
            // nowy wiersz
            cur_x = x;
            cur_y += line_height;
        }
        al_draw_text(font, color, cur_x, cur_y, 0, word);
        cur_x += w + al_get_text_width(font, " ");  // przerwa
        word = strtok(NULL, " ");
    }
}

void debugujListe(Pytanie* glowa) {
    if (!glowa) {
        printf("Lista jest pusta!\n");
        return;
    }
    Pytanie* temp = glowa;
    int licznik = 0;
    do {
        printf("[DEBUG] Pytanie %d: %s\n", licznik, temp->tresc);
        temp = temp->nastepne;
        licznik++;
    } while (temp != glowa && licznik < MAKSYMALNA_ILOSC_PYTAN); // Zabezpieczenie przed nieskończoną pętlą
}


void inicjalizuj_stan_gry(ProfilGracz* profil, int ileLatwych, int ileSrednich, int ileTrudnych) {
    // Wczytaj pytania z plików
    czcionka_mala = al_load_ttf_font("tahoma.ttf", 18, 0);
    if (!czcionka_mala) {
        fprintf(stderr, "BŁĄD: Nie znaleziono czcionki tahoma.ttf!\n");
        exit(1);
    }

    //  DEBUGOWANIE
    if (ileLatwych == 0 && ileSrednich == 0 && ileTrudnych == 0) {
        fprintf(stderr, "BŁĄD: Brak pytań we wszystkich plikach!\n");
        exit(1);
    }
    //

    Pytanie* pytaniaLatwe[MAKSYMALNA_ILOSC_PYTAN];
    Pytanie* pytaniaSrednie[MAKSYMALNA_ILOSC_PYTAN];
    Pytanie* pytaniaTrudne[MAKSYMALNA_ILOSC_PYTAN];

    int iloscLatwe = wczytajWszystkiePytania("latwy.txt", pytaniaLatwe, &iloscLatwe);
    int iloscSrednie = wczytajWszystkiePytania("sredni.txt", pytaniaSrednie, &iloscSrednie);
    int iloscTrudne = wczytajWszystkiePytania("trudny.txt", pytaniaTrudne, &iloscTrudne);

    // DEBUGOWANIE
    printf("Finalna liczba pytań: Ł=%d, Ś=%d, T=%d\n",ileLatwych,ileSrednich,ileTrudnych);
    // 

    // Ogranicz liczbę pytań, jeśli brakuje
    if (ileLatwych > iloscLatwe) ileLatwych = iloscLatwe;
    if (ileSrednich > iloscSrednie) ileSrednich = iloscSrednie;
    if (ileTrudnych > iloscTrudne) ileTrudnych = iloscTrudne;

    // Stwórz listę pytań
    Pytanie* glowa = NULL;
    wybierzLosowePytaniaZPoziomow(pytaniaLatwe, iloscLatwe, pytaniaSrednie, iloscSrednie,
        pytaniaTrudne, iloscTrudne, ileLatwych, ileSrednich, ileTrudnych, &glowa);

    // Załaduj zasoby graficzne
    tlo_gry = al_load_bitmap("way.png");
    if (!tlo_gry) {
        fprintf(stderr, "BŁĄD: Nie znaleziono pliku way.png!\n");
        exit(1);
    }

    czcionka_duza = al_load_ttf_font("tahoma.ttf", 24, 0);
    if (!czcionka_duza) {
        fprintf(stderr, "BŁĄD: Nie znaleziono czcionki arial.ttf!\n");
        exit(1);
    }


    // DEBUGOWANIE
    printf("Adres glowy listy po inicjalizacji: %p\n", (void*)glowa);
    //

    // Inicjalizuj strukturę stan_gry
    stan_gry.aktualne_pytanie = glowa;
    stan_gry.lista_pytan = glowa;
    stan_gry.numer_pytania = 0;
    stan_gry.licznik_poprawnych = 0;
    stan_gry.kolo50_uzyte = 0;
    stan_gry.telefon_uzyty = 0;
    stan_gry.ukryte_odpowiedzi = calloc(4, sizeof(int)); 
    stan_gry.profil = profil;
    stan_gry.ileLatwych = ileLatwych;
    stan_gry.ileSrednich = ileSrednich;
    stan_gry.ileTrudnych = ileTrudnych;

    // Sprawdzenie, czy lista pytań jest poprawna
    if (stan_gry.lista_pytan == NULL) {
        fprintf(stderr, "BŁĄD: Lista pytań jest pusta!\n");
        // exit(1);
    }

    printf("[DEBUG] Adres glowy listy: %p\n", (void*)glowa);
    if (!glowa) {
        fprintf(stderr, "BŁĄD: Lista pytań jest pusta!\n");
        exit(1);
    }
    debugujListe(glowa);

}


void rysuj_gre() {
    al_draw_bitmap(tlo_gry, 0, 0, 0);
    al_draw_text(czcionka_duza, al_map_rgb(255, 255, 255), 50, 50, 0, stan_gry.aktualne_pytanie->tresc);

    // Odpowiedzi (nowe współrzędne)
   // for (int i = 0; i < 4; i++) {
   //     int y = 150 + i * 100; // Odstęp 100px między odpowiedziami
   //     if (!stan_gry.ukryte_odpowiedzi[i]) {
   //         al_draw_filled_rectangle(100, y, 700, y + 50, al_map_rgb(75, 75, 200));
   //         al_draw_text(czcionka_mala, al_map_rgb(255, 255, 255), 120, y + 15, 0, stan_gry.aktualne_pytanie->odpowiedzi[i]);
   //     }
   // }

    for (int i = 0; i < liczba_przyciskow_gry; i++) {
        Przycisk p = przyciski_gry[i];
        ALLEGRO_COLOR kolor = al_map_rgba(0, 0, 0,0); // domyślnie czerwony

        if (strcmp(p.akcja, "TELEFON") == 0 || strcmp(p.akcja, "POL_NA_POL") == 0)
            kolor = al_map_rgba(50, 100, 200,0); // niebieski dla kół ratunkowych

        al_draw_filled_rectangle(p.x, p.y, p.x + p.width, p.y + p.height, kolor);
        al_draw_rectangle(p.x, p.y, p.x + p.width, p.y + p.height, al_map_rgb(0, 0, 0), 2);

        if (strncmp(p.akcja, "ODP_", 4) == 0) {
            int idx = p.akcja[4] - 'A';
            if (!stan_gry.ukryte_odpowiedzi[idx]) {
                al_draw_textf(czcionka_mala, al_map_rgb(255, 255, 255), p.x + 15, p.y + 20, 0, "%c) %s", 'A' + idx, stan_gry.aktualne_pytanie->odpowiedzi[idx]);
            }
        }
        else if (strcmp(p.akcja, "TELEFON") == 0) {
            al_draw_text(czcionka_mala, al_map_rgba(255, 255, 255,0), p.x + 20, p.y + 20, 0, "");
        }
        else if (strcmp(p.akcja, "POL_NA_POL") == 0) {
            al_draw_text(czcionka_mala, al_map_rgba(255, 255, 255,0), p.x + 20, p.y + 20, 0, "");
        }
    }
}

void zakoncz_gre() {
    // Oblicza poprawne odpowiedzi dla każdego poziomu trudności
    int correct_easy = 0, correct_medium = 0, correct_hard = 0;
    Pytanie* aktualne = stan_gry.lista_pytan;

    for (int i = 0; i < stan_gry.numer_pytania; i++) {
        if (i < stan_gry.ileLatwych) {
            correct_easy++;
        }
        else if (i < stan_gry.ileLatwych + stan_gry.ileSrednich) {
            correct_medium++;
        }
        else {
            correct_hard++;
        }
        aktualne = aktualne->nastepne;
    }

    progres(stan_gry.profil, correct_easy, correct_medium, correct_hard, MAKS_PROFILE);

    free(stan_gry.ukryte_odpowiedzi);
    al_destroy_bitmap(tlo_gry);
    al_destroy_font(czcionka_duza);
    al_destroy_font(czcionka_mala);
    stan = STAN_MENU;
}


void obsluguj_gre(ALLEGRO_EVENT* event) {
    if (event->type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
        float x = event->mouse.x;
        float y = event->mouse.y;

        printf("Kliknięto: %.0f, %.0f\n", x, y);  // DEBUG

        for (int i = 0; i < liczba_przyciskow_gry; ++i) {
            Przycisk p = przyciski_gry[i];

            if (x >= p.x && x <= p.x + p.width &&
                y >= p.y && y <= p.y + p.height) {

                printf("Klik w przycisk: %s\n", p.akcja);  // DEBUG

                if (strcmp(p.akcja, "TELEFON") == 0 && !stan_gry.telefon_uzyty) {
                    TelefonDoPrzyjaciela(stan_gry.aktualne_pytanie, stan_gry.ukryte_odpowiedzi);
                    stan_gry.telefon_uzyty = 1;
                    return;
                }

                if (strcmp(p.akcja, "POL_NA_POL") == 0 && !stan_gry.kolo50_uzyte) {
                    Kolo50(stan_gry.aktualne_pytanie, stan_gry.ukryte_odpowiedzi);
                    stan_gry.kolo50_uzyte = 1;
                    return;
                }

                if (strncmp(p.akcja, "ODP_", 4) == 0) {
                    int idx = p.akcja[4] - 'A';
                    char odpowiedz = 'A' + idx;
                    if (odpowiedz == stan_gry.aktualne_pytanie->poprawna_odpowiedz) {
                        stan_gry.licznik_poprawnych++;
                        stan_gry.numer_pytania++;
                        stan_gry.aktualne_pytanie = stan_gry.aktualne_pytanie->nastepne;
                        stan_gry.kolo50_uzyte = 0;
                        stan_gry.telefon_uzyty = 0;

                        for (int j = 0; j < 4; j++) {
                            stan_gry.ukryte_odpowiedzi[j] = 0;
                        }
                        stan_gry.kolo50_uzyte = 0;
                        stan_gry.telefon_uzyty = 0;
                    }
                    else {
                        stan = STAN_KONIEC_GRY;
                    }
                    return;
                }
            }
        }
    }
}

////////////////////////
void obsluguj_poziomy(ALLEGRO_EVENT* event) {
    if (event->type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
        float mouse_x = event->mouse.x;
        float mouse_y = event->mouse.y;

        Przycisk przyciski_poziomow[] = {
        {241, 150, 324, 82, "LATWY"},
        {241, 250, 324, 82, "SREDNI"},
        {241, 350, 324, 82, "TRUDNY"},
        {241, 450, 324, 82, "POWROT_POZIOM"}
        };

        for (int i = 0; i < 4; ++i) {
            Przycisk p = przyciski_poziomow[i];
            if (mouse_x >= p.x && mouse_x <= p.x + p.width &&
                mouse_y >= p.y && mouse_y <= p.y + p.height) {

                if (strcmp(p.akcja, "LATWY") == 0) {
                    inicjalizuj_stan_gry(aktywny_profil, 8, 4, 0);
                    stan = STAN_GRY;
                }
                else if (strcmp(p.akcja, "SREDNI") == 0) {
                    if (strcmp(aktywny_profil->ranga, "Technik Informatyk") == 0) {
                        inicjalizuj_stan_gry(aktywny_profil, 5, 5, 2);
                        stan = STAN_GRY;
                    }
                }
                else if (strcmp(p.akcja, "TRUDNY") == 0) {
                    if (strcmp(aktywny_profil->ranga, "Magister") == 0 ||
                        strcmp(aktywny_profil->ranga, "Profesor") == 0) {
                        inicjalizuj_stan_gry(aktywny_profil, 3, 4, 5);
                        stan = STAN_GRY;
                    }
                }
                else if (strcmp(p.akcja, "POWROT_POZIOM") == 0) {
                    stan = STAN_MENU;
                    al_rest(0.5);
                    exit(0);
                }
            }
        }
    }
}

////////////////////////
ProfilGracz profile[MAKS_PROFILE];
int liczba_profili = 0;
bool wprowadzenie_nazwy = false;
bool usuwanie_profilu = false;


////////////////////////////////////////////////////////////////////////////////////// Główna funkcja programu
int main() {

    // KCH: Wskaźniki ogólne
    ALLEGRO_DISPLAY* display;
    ALLEGRO_EVENT_QUEUE* queue;
    ALLEGRO_TIMER* timer;

    // KCH: Wskaźniki graficzne
    ALLEGRO_BITMAP* bitmap = NULL;
    ALLEGRO_BITMAP* cursor = NULL;
    ALLEGRO_BITMAP* instrukcja = NULL;
    ALLEGRO_BITMAP* profil = NULL;

    // KCH: Wskaźniki dźwiękowe
    ALLEGRO_SAMPLE* sample = NULL;
    ALLEGRO_SAMPLE* click = NULL;

    //StanGry stan = STAN_MENU; // KCH: ustawienie początkowego stanu gry na menu główne, jak narazie używane podczas zmiany z menu na ekran instrukcji
     // KCH: Każdy ekran będzie miał swój stan gry. W jaki sposób zrobi się to wszystko to nie wiem ale będzie łatwiej ze stanami

    if (!al_init()) {
        fprintf(stderr, "Nie udało się zainicjalizować Allegro!\n");
        return -1;
    }

    al_init_font_addon();
    al_init_ttf_addon();
    al_init_image_addon();
    al_install_audio();
    al_init_acodec_addon();
    al_init_primitives_addon();
    al_install_mouse();
    al_install_keyboard(); // KCH: inicjalizacja i instalacja potrzebnych modułów do otwierania plików i do sterowania

    display = al_create_display(800, 600); // KCH: Utworzenie ekranu 800x600
    if (!display) {
        fprintf(stderr, "Nie udało się stworzyć okna!\n");
        return -1;
    }

    al_hide_mouse_cursor(display); // KCH: Schowanie domyślnego kursora Windows aby przygotować go pod niestandardowy obrazek

    queue = al_create_event_queue();
    timer = al_create_timer(1.0 / 60); // KCH: Czas co który gra się odświeża, 60 klatek na sekundę

    al_reserve_samples(2);
    sample = al_load_sample("eciopecio.mp3"); // KCH: Tymczasowy podkład
    if (!sample) {
        fprintf(stderr, "Błąd: Nie udało się załadować pliku eciopecio.mp3\n");
        return -1;
    }

    click = al_load_sample("click1.wav");
    if (!click) {
        fprintf(stderr, "Błąd: Nie udało się załadować click.mp3\n");
        return -1;
    }

    bitmap = al_load_bitmap("mainmenu.png"); // KCH: Menu główne
    assert(bitmap != NULL);

    cursor = al_load_bitmap("cursor.png"); // KCH: Niestandardowy kursor
    assert(cursor != NULL);

    Przycisk przyciski[] = { // KCH: Lista wszystkich przycisków. Jak narazie istnieje tylko trzy z menu głównego. Instrukcja jest obsługiwana klawiaturą
        {241, 298, 324, 82, "GRAJ"},
        {241, 398, 324, 82, "INSTRUKCJA"},
        {241, 497, 324, 82, "WYJSCIE"},

        // KCH: przycisku stangry = profil
        {241, 95, 324, 82, "PROFIL1"},
        {241, 194, 324, 82, "PROFIL2"},
        {241, 294, 324, 82, "PROFIL3"},
        {241, 398, 148, 45, "DODAJPROFIL"},
        {415, 398, 148, 45, "USUNPROFIL"},
        {241, 464, 324, 82, "PROFILPOWROT"},

    };




    const int liczba_przyciskow = sizeof(przyciski) / sizeof(Przycisk); // KCH: Liczy ilość przycisków

    al_register_event_source(queue, al_get_mouse_event_source());
    al_register_event_source(queue, al_get_keyboard_event_source());
    al_register_event_source(queue, al_get_display_event_source(display));
    al_register_event_source(queue, al_get_timer_event_source(timer)); // KCH: Rejestrowanie różnych źródeł zdarzeń

    al_start_timer(timer); // KCH: Uruchomienie zegara
    wczytaj_profile(profile, &liczba_profili);
    al_play_sample(sample, 0.75, 0.0, 1.0, ALLEGRO_PLAYMODE_LOOP, NULL); // KCH: Podkład który gra podczas rozgrywki, jak narazie gra przetworzoną wersję Oasis - Soldier On

    bool running = true; // KCH: Domyślnie uruchamia program.
    // W teorii powinno zamknąć program gdy running = false, jednakże po ustawieniu zmiennej running na false
     // program się wiesza i jedynym sposobem na zamknięcie programu jest zmuszenie kompilatora do zaprzestania działania

    float mouse_x = 0, mouse_y = 0; // KCH: Zmienne pozycji myszki x oraz y
    ALLEGRO_FONT* font = al_load_ttf_font("tahoma.ttf", 12, 0); // KCH: Wczytanie głównej czcionki

    while (running) { // KCH: Pętla graficzna gry, wszystko poniżej poza tej pętli jest nie wyświetlane i technicznie nieważne
        ALLEGRO_EVENT event;
        al_wait_for_event(queue, &event);


        ////
        if (event.type == ALLEGRO_EVENT_KEY_CHAR && wprowadzanie_nazwy) { // KCH: WIELGAŚNA funkcja dodawania profilów
            int len = strlen(wpisywany_tekst);

            if (event.keyboard.unichar == '\b') { // Backspace
                if (len > 0) wpisywany_tekst[len - 1] = '\0';
            }
            else if (event.keyboard.unichar == '\r') { // Enter – zakończ i zapisz
                if (len > 0 && liczba_profili < MAKS_PROFILE) {
                    strcpy(profile[liczba_profili].nazwa_gracza, wpisywany_tekst);
                    profile[liczba_profili].xp = 0;
                    strcpy(profile[liczba_profili].ranga, "Technik Informatyk");
                    liczba_profili++;
                    zapis_gracz(profile, liczba_profili);
                }
                wpisywany_tekst[0] = '\0';
                wprowadzanie_nazwy = false;
            }
            else if (len < MAKS_NAZWA - 1 && event.keyboard.unichar >= 32 && event.keyboard.unichar <= 126) {
                wpisywany_tekst[len] = (char)event.keyboard.unichar;
                wpisywany_tekst[len + 1] = '\0';
            }
        }
        ////

        ////
        if (usuwanie_profilu) { // KCH funkcja usuwania profilów
            int len = strlen(wpisywany_tekst);

            if (event.keyboard.unichar == '\b') {
                if (len > 0) wpisywany_tekst[len - 1] = '\0';
            }
            else if (event.keyboard.unichar == '\r') { // Enter - zatwierdź usunięcie
                if (len > 0) {
                    int nr = atoi(wpisywany_tekst);
                    if (nr >= 1 && nr <= liczba_profili) {
                        // przesunięcie tablicy profili "w górę"
                        for (int i = nr - 1; i < liczba_profili - 1; i++) {
                            profile[i] = profile[i + 1];
                        }
                        liczba_profili--;
                        zapis_gracz(profile, liczba_profili);
                        printf("Usunięto profil nr %d\n", nr);
                    }
                    else {
                        printf("Nieprawidłowy numer profilu!\n");
                    }
                }
                wpisywany_tekst[0] = '\0';
                usuwanie_profilu = false;
            }
            else if (len < MAKS_NAZWA - 1 && event.keyboard.unichar >= '0' && event.keyboard.unichar <= '9') {
                wpisywany_tekst[len] = (char)event.keyboard.unichar;
                wpisywany_tekst[len + 1] = '\0';
            }
        }
        ////



        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { // 
            exit(0); // KCH: Zamknięcie gry poprzez kliknięcie X na okienku Windows. Wcześniej było tu running = false ale były z tym problemy
        }

        if (event.type == ALLEGRO_EVENT_MOUSE_AXES) { // KCH: Aktualizuje pozycję myszki i przypisuje je do zmiennych
            mouse_x = event.mouse.x;
            mouse_y = event.mouse.y;
        }

        if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {  // KCH: Wydarzenia przypisane pod przycisk myszy
            al_play_sample(click, 0.25, 0.0, 2.0, ALLEGRO_PLAYMODE_ONCE, NULL);  // KCH: Dźwięk klikania który pojawia się po każdym kliknięciu 



            if (stan == STAN_MENU) { // KCH: Sprawdzenie stanu gry, działa tylko gdy jest w menu głównym
                for (int i = 0; i < liczba_przyciskow; ++i) {  // KCH: Pętla sprawdzająca czy dany przycisk został wciśnięty
                    Przycisk p = przyciski[i];
                    if (mouse_x >= p.x && mouse_x <= p.x + p.width &&
                        mouse_y >= p.y && mouse_y <= p.y + p.height) {

                        if (strcmp(p.akcja, "GRAJ") == 0) {
                            if (profil) al_destroy_bitmap(profil);
                            profil = al_load_bitmap("profil.png");
                            if (!profil) {
                                fprintf(stderr, "Nie udało się załadować profil.png\n");
                                running = false;
                            }
                            else {
                                stan = STAN_PROFIL;
                            }
                        }
                        else if (strcmp(p.akcja, "INSTRUKCJA") == 0) {  // KCH: Przycisk Instrukcja, pokazuje duhhh instrukcje :PPPP
                            if (instrukcja) al_destroy_bitmap(instrukcja);
                            instrukcja = al_load_bitmap("instrukcja.png");
                            if (!instrukcja) {
                                fprintf(stderr, "Nie udało się załadować instrukcja.png\n");
                                running = false;
                            }
                            else {
                                stan = STAN_INSTRUKCJA;  // KCH: Zamienia stan gry z STAN_MENU na STAN_INSTRUKCJA, wychodząc z pętli na spacerek
                            }
                        }
                        else if (strcmp(p.akcja, "WYJSCIE") == 0) {  // KCH: Przycisk Wyjście
                            al_rest(0.5);
                            exit(0);
                        }
                    }
                }
            }
            if (stan == STAN_POZIOM) {
                obsluguj_poziomy(&event);
                rysuj_poziomy();
            }

            if (stan == STAN_PROFIL) {
                for (int i = 3; i < 9; ++i) { // Przyciski PROFIL1-PROFIL3
                    Przycisk p = przyciski[i];
                    if (mouse_x >= p.x && mouse_x <= p.x + p.width &&
                        mouse_y >= p.y && mouse_y <= p.y + p.height) {

                        int profil_index = i - 3;
                        if (profil_index < liczba_profili) {
                            aktywny_profil = &profile[profil_index];
                            aktywny_profil_index = profil_index;

                            // Przejdź do wyboru poziomu
                            if (poziom_bitmap) al_destroy_bitmap(poziom_bitmap);
                            poziom_bitmap = al_load_bitmap("poziom.png");
                            stan = STAN_POZIOM;
                        }

                        if (strcmp(p.akcja, "DODAJPROFIL") == 0) {
                            wprowadzanie_nazwy = true;
                            wpisywany_tekst[0] = '\0';
                        }

                        if (strcmp(p.akcja, "USUNPROFIL") == 0) {
                            usuwanie_profilu = true;
                            wpisywany_tekst[0] = '\0';
                        }

                        if (strcmp(p.akcja, "PROFILPOWROT") == 0) {
                            stan = STAN_MENU;
                            if (profil) {
                                al_destroy_bitmap(profil);
                                profil = NULL;
                            }
                        }
                    }
                }

                if (wprowadzanie_nazwy) {
                    ALLEGRO_FONT* font = al_create_builtin_font();
                    al_draw_filled_rectangle(200, 500, 600, 540, al_map_rgb(255, 255, 255));
                    al_draw_rectangle(200, 500, 600, 540, al_map_rgb(0, 0, 0), 2);
                    al_draw_textf(font, al_map_rgb(0, 0, 0), 210, 510, 0, "Nowy profil: %s", wpisywany_tekst);
                    al_destroy_font(font);
                }

            }
        }


        if (event.type == ALLEGRO_EVENT_KEY_DOWN) { // KCH: Kontynuacja przycisku Instrukcja
            if (stan == STAN_INSTRUKCJA && event.keyboard.keycode == ALLEGRO_KEY_ENTER) { // Sprawdza czy aktualny stan gry to Instrukcja i czy klawisz enter został wciśnięty
                al_play_sample(click, 0.25, 0.0, 2, ALLEGRO_PLAYMODE_ONCE, NULL);
                stan = STAN_MENU; // Spełniony warunek i gra zmienia stan z Instrukcja na Menu
                if (instrukcja) {
                    al_destroy_bitmap(instrukcja); // Zwalnianie pamięci
                    instrukcja = NULL;
                }
            }
        }

        if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
            if (stan == STAN_GRY) {
                obsluguj_gre(&event); 
            }
        }



        if (event.type == ALLEGRO_EVENT_TIMER) {
            al_clear_to_color(al_map_rgb(64, 64, 64));

            switch (stan) {
            case STAN_MENU:
                al_draw_bitmap(bitmap, 0, 0, 0);
                break;
            case STAN_INSTRUKCJA:
                if (instrukcja) al_draw_bitmap(instrukcja, 0, 0, 0);
                break;
            case STAN_PROFIL:
                if (profil)
                    al_draw_bitmap(profil, 0, 0, 0);

                for (int i = 0; i < liczba_profili; i++) { // KCH: Wyświetlenie profili
                    int base_x = 300;
                    int base_y = 80 + i * 98;

                    al_draw_textf(font, al_map_rgb(255, 255, 255), base_x, base_y + 25, 0, "%s", profile[i].nazwa_gracza);
                    al_draw_textf(font, al_map_rgb(255, 255, 255), base_x, base_y + 50, 0, "XP: %d", profile[i].xp);
                    al_draw_textf(font, al_map_rgb(255, 255, 255), base_x, base_y + 75, 0, "Ranga: %s", profile[i].ranga);
                }

                if (wprowadzanie_nazwy) {
                    ALLEGRO_FONT* font = al_load_ttf_font("tahoma.ttf", 18, 0);
                    al_draw_filled_rectangle(200, 500, 600, 540, al_map_rgb(255, 255, 255));
                    al_draw_rectangle(200, 500, 600, 540, al_map_rgb(0, 0, 0), 2);
                    al_draw_textf(font, al_map_rgb(0, 0, 0), 210, 510, 0, "Nowy profil: %s", wpisywany_tekst);
                    al_destroy_font(font);
                }

                if (usuwanie_profilu) {
                    ALLEGRO_FONT* font = al_load_ttf_font("tahoma.ttf", 18, 0);
                    al_draw_filled_rectangle(200, 500, 650, 540, al_map_rgb(255, 255, 255));
                    al_draw_rectangle(200, 500, 650, 540, al_map_rgb(0, 0, 0), 2);
                    al_draw_textf(font, al_map_rgb(0, 0, 0), 210, 510, 0, "Usun profil nr: %s", wpisywany_tekst);
                    al_destroy_font(font);
                }
                break;




            case STAN_POZIOM:
                rysuj_poziomy();
                break;
            case STAN_GRY: // DODAJ TEN PRZYPADEK
                fprintf(stderr, "JESTESMY TU!\n");
                al_clear_to_color(al_map_rgb(0, 0, 0)); // Reset ekranu
                rysuj_gre();
                al_draw_bitmap(cursor, mouse_x, mouse_y, 0); // Kursor na wierzchu
                al_flip_display(); // Wymuś aktualizację
                break;
            case STAN_KONIEC_GRY:
                zakoncz_gre();
                break;
            }


            al_draw_bitmap(cursor, mouse_x, mouse_y, 0); // KCH: Nakłada niestandardowy obrazek na pozycję kursora

            al_flip_display(); // KCH: Odświeża ekran (double buffering, crazy rzeczy)
        }
    }

    // al_destroy_font(font);
    al_destroy_display(display);
    al_destroy_bitmap(bitmap);
    al_destroy_timer(timer);
    al_destroy_sample(click);
    al_destroy_sample(sample);
    al_uninstall_keyboard();
    al_uninstall_mouse(); // KCH: Odłączanie usuwanie funkcji allegro by uniknąć padaczki

    return 0;
}